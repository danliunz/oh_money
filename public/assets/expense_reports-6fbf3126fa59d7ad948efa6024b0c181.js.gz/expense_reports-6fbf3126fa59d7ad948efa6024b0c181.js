$(document).ready(function() {
  init_item_type_autocomplete();
  init_tag_autocomplete();
});
